console.log('Mi primer programa');
console.log(2+2);

const nombreMadre = "María";
const nombrePadre = "José";
const nombreHijo = "Jesús";

const edadMadre = 60;

console.log(nombreMadre);
console.log("El nombre de mi madre es "+nombreMadre);
console.log("La edad de mi madre es "+edadMadre);
