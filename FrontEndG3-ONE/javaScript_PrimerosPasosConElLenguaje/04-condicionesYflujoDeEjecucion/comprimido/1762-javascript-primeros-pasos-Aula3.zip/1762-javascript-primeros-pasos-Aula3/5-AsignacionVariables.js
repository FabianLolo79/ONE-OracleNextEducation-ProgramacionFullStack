console.log("Asignando valores a las variables");

const miNombre = "Leonardo";
const miApellido = "Lacruz";
console.log(miNombre);

const miNombreCompleto = miNombre + " " + miApellido;
console.log(miNombreCompleto);

const textoMiNombre = `Mi nombre es: ${miNombre} ${miApellido}`;
console.log(textoMiNombre);

const textoMiNombreDobles = "Mi nombre es: ${miNombre} ${miApellido}";
console.log(textoMiNombreDobles);

const textoMiNombreSimples = 'Mi nombre es: ${miNombre} ${miApellido}';
console.log(textoMiNombreSimples);

let variableTexto = "Un texto";
console.log(variableTexto);

variableTexto = 10;
console.log(variableTexto);

variableTexto = 10.5;
console.log(variableTexto);

variableTexto = false;
console.log(variableTexto);