console.log('Conversion de Tipos de datos');

console.log("10" + "2");

console.log(parseInt("10") + parseInt("2"));

console.log("10" / "2");

console.log("Maria" / "2");